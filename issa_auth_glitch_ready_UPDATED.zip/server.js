const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bodyParser = require("body-parser");
const dotenv = require("dotenv");
dotenv.config();

const authRoutes = require("./routes/authRoutes");
const emailRoute = require("./routes/emailRoute");

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.use("/api", authRoutes);
app.use("/api", emailRoute);
app.use(express.static("public"));

mongoose.connect(process.env.MONGO_URI)
.then(() => {
    app.listen(3000, () => console.log("Server running on port 3000"));
})
.catch(err => console.log("MongoDB connection error:", err));
